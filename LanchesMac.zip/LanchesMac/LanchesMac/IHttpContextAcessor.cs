﻿namespace LanchesMac
{
    internal interface IHttpContextAcessor
    {
    }
}